import {
  AdjustmentsHorizontalIcon,
  BanknotesIcon,
  CalendarDaysIcon,
  ChartBarSquareIcon,
  ClipboardDocumentCheckIcon,
  ClipboardDocumentListIcon,
  Cog6ToothIcon,
  CreditCardIcon,
  DocumentChartBarIcon,
  DocumentTextIcon,
  HomeIcon,
  MapPinIcon,
  PresentationChartLineIcon,
  ReceiptPercentIcon,
  ShieldCheckIcon,
  UserGroupIcon,
  UsersIcon,
  WrenchScrewdriverIcon,
} from '@heroicons/react/24/outline';
export const AdminNav = [
  {
    id: 'principal',
    title: 'Panel principal',
    icon: HomeIcon,
    items: [
      {
        label: 'Dashboard',
        to: '/admin/dashboard',
        icon: PresentationChartLineIcon,
      },
    ],
  },

  {
    id: 'socios',
    title: 'Socios',
    icon: UserGroupIcon,
    items: [
      {
        label: 'Administrar socios',
        to: '/admin/socios',
        icon: UsersIcon,
        permission: ['socio.ver', 'socios.ver', 'socios.socio.ver'],
      },
    ],
  },

  {
    id: 'gestion-acciones',
    title: 'Gestión de acciones',
    icon: ClipboardDocumentListIcon,
    items: [
      {
        label: 'Acciones de agua',
        to: '/admin/acciones',
        icon: ClipboardDocumentListIcon,
        permission: ['acciones.accion.ver', 'accion.ver', 'acciones.ver'],
      },
      {
        label: 'Acciones de alcantarillado',
        to: '/admin/alcantarillado/acciones',
        icon: WrenchScrewdriverIcon,
        permission: ['acciones.accion.ver', 'accion.ver', 'acciones.ver'],
      },
      {
        label: 'Cambio de propietario',
        to: '/admin/cambio-nombre',
        icon: ClipboardDocumentCheckIcon,
        permission: ['acciones.accion.ver', 'accion.ver', 'acciones.ver'],
      },
    ],
  },

  {
    id: 'configuracion-acciones',
    title: 'Configuración de acciones',
    icon: Cog6ToothIcon,
    items: [
      {
        label: 'Tipos de acción',
        to: '/admin/tipo-accion',
        icon: ClipboardDocumentListIcon,
        permission: ['acciones.accion.ver', 'accion.ver', 'acciones.ver'],
      },
      {
        label: 'Detalles de acción',
        to: '/admin/detalle-pago-accion',
        icon: DocumentChartBarIcon,
        permission: [
          'acciones.detalle.ver',
          'acciones.detalles.ver',
          'detalle_accion.ver',
          'detalle_pago_accion.ver',
        ],
      },
      {
        label: 'Detalles de alcantarillado',
        to: '/admin/alcantarillado',
        icon: WrenchScrewdriverIcon,
        permission: ['acciones.accion.ver', 'accion.ver', 'acciones.ver'],
      },
      {
        label: 'Tarifas',
        to: '/admin/tarifas',
        icon: AdjustmentsHorizontalIcon,
        permission: ['tarifa.ver', 'tarifas.ver'],
      },
    ],
  },

  {
    id: 'lecturador',
    title: 'Lecturador',
    icon: DocumentTextIcon,
    items: [
      {
        label: 'Registro de lecturas',
        to: '/admin/lecturas',
        icon: DocumentTextIcon,
        permission: ['lectura.ver', 'lecturas.ver', 'agua.lectura.ver'],
      },
      {
        label: 'Cobros de lectura',
        to: '/admin/cobros-agua',
        icon: ReceiptPercentIcon,
        permission: [
          'pago_agua.ver',
          'pago-agua.ver',
          'cobro_agua.ver',
          'cobros_agua.ver',
          'agua.cobro.ver',
        ],
      },
      {
        label: 'Mora',
        to: '/admin/lectura-mora',
        icon: DocumentTextIcon,
        permission: ['lectura.ver', 'lecturas.ver', 'agua.lectura.ver'],
      },
    ],
  },

  {
    id: 'cobros',
    title: 'Cobros y pagos',
    icon: BanknotesIcon,
    items: [
      {
        label: 'Cobros generales',
        to: '/admin/cobros',
        icon: CreditCardIcon,
        permission: ['cobro.ver', 'cobros.ver', 'pago.ver', 'pagos.ver'],
      },
      {
        label: 'Cobros universales',
        to: '/admin/cobros-universales',
        icon: BanknotesIcon,
        permission: ['cobro.ver', 'cobros.ver', 'pago.ver', 'pagos.ver'],
      },
      {
        label: 'Cobros de alcantarillado',
        to: '/admin/alcantarillado-cobros',
        icon: ReceiptPercentIcon,
        permission: ['acciones.accion.ver', 'accion.ver', 'acciones.ver'],
      },
    ],
  },

  {
    id: 'reuniones',
    title: 'Multas y reuniones',
    icon: CalendarDaysIcon,
    items: [
      {
        label: 'Multas',
        to: '/admin/multas',
        icon: ReceiptPercentIcon,
        permission: ['multa.ver', 'multas.ver'],
      },
      {
        label: 'Asambleas',
        to: '/admin/asambleas',
        icon: CalendarDaysIcon,
        permission: [
          'asamblea.ver',
          'asambleas.ver',
          'reunion.ver',
          'reuniones.ver',
        ],
      },
    ],
  },

  {
    id: 'administracion',
    title: 'Administración',
    icon: WrenchScrewdriverIcon,
    items: [
      {
        label: 'Gestiones',
        to: '/admin/gestiones',
        icon: CalendarDaysIcon,
        permission: ['gestion.ver', 'gestiones.ver'],
      },
      {
        label: 'Periodos',
        to: '/admin/periodos',
        icon: ClipboardDocumentCheckIcon,
        permission: ['periodo.ver', 'periodos.ver', 'gestion.ver'],
      },
      {
        label: 'Calles',
        to: '/admin/calles',
        icon: MapPinIcon,
        permission: ['calle.ver', 'calles.ver', 'acciones.calles.ver'],
      },
    ],
  },

  {
    id: 'seguridad',
    title: 'Usuarios y permisos',
    icon: ShieldCheckIcon,
    items: [
      {
        label: 'Usuarios',
        to: '/admin/usuarios',
        icon: UsersIcon,
        permission: ['usuario.ver', 'usuarios.ver', 'auth.usuario.ver'],
      },
      {
        label: 'Roles',
        to: '/admin/roles',
        icon: ShieldCheckIcon,
        permission: ['rol.ver', 'roles.ver', 'auth.rol.ver'],
      },
    ],
  },

  {
    id: 'reportes',
    title: 'Reportes',
    icon: ChartBarSquareIcon,
    items: [
      {
        label: 'Reportes generales',
        to: '/admin/reportes',
        icon: ChartBarSquareIcon,
        permission: ['reporte.ver', 'reportes.ver'],
      },
    ],
  },
];