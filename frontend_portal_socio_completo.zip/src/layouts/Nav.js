import {
  AdjustmentsHorizontalIcon,
  BanknotesIcon,
  CalendarDaysIcon,
  ChartBarSquareIcon,
  ClipboardDocumentCheckIcon,
  ClipboardDocumentListIcon,
  Cog6ToothIcon,
  CreditCardIcon,
  DocumentChartBarIcon,
  DocumentTextIcon,
  HomeIcon,
  MapPinIcon,
  PresentationChartLineIcon,
  ReceiptPercentIcon,
  ShieldCheckIcon,
  UserGroupIcon,
  UsersIcon,
  WrenchScrewdriverIcon,
} from '@heroicons/react/24/outline';

/**
 * Navegación principal del panel administrativo.
 *
 * Orden recomendado:
 * 1. Resumen y operación diaria.
 * 2. Gestión comercial y cobros.
 * 3. Socios.
 * 4. Configuración.
 * 5. Asambleas.
 * 6. Reportes.
 */
export const AdminNav = [
  {
    id: 'principal',
    title: 'Panel principal',
    icon: HomeIcon,
    items: [
      {
        label: 'Dashboard',
        to: '/admin/dashboard',
        icon: PresentationChartLineIcon,
      },
    ],
  },

  {
    id: 'socios',
    title: 'Socios',
    icon: UserGroupIcon,
    items: [
      {
        label: 'Administrar socios',
        to: '/admin/socios',
        icon: UsersIcon,
        permission: ['socio.ver', 'socios.ver', 'socios.socio.ver'],
      },
      // {
      //   label: 'Acciones',
      //   to: '/admin/acciones',
      //   icon: ClipboardDocumentListIcon,
      //   permission: ['acciones.accion.ver', 'accion.ver', 'acciones.ver'],
      // },

      // {
      //   label: 'Detalle de acción',
      //   to: '/admin/detalle-pago-accion',
      //   icon: DocumentChartBarIcon,
      //   permission: [
      //     'acciones.detalle.ver',
      //     'acciones.detalles.ver',
      //     'detalle_accion.ver',
      //     'detalle_pago_accion.ver',
      //   ],
      // },
      // {
      //   label: 'Alcantarillado',
      //   to: '/admin/alcantarillado',
      //   icon: WrenchScrewdriverIcon,
      //   permission: ['acciones.accion.ver', 'accion.ver', 'acciones.ver'],
      // },
      // {
      //   label: 'Cambio de nombre',
      //   to: '/admin/cambio-nombre',
      //   icon: ClipboardDocumentCheckIcon,
      //   permission: ['acciones.accion.ver', 'accion.ver', 'acciones.ver'],
      // },
      // //Añadido por Becas
      // {
      //   label: 'Tipo Accion',
      //   to: '/admin/tipo-accion',
      //   icon: ClipboardDocumentListIcon,
      //   permission: ['acciones.accion.ver', 'accion.ver', 'acciones.ver'],
      // },
    ],
  },
  {
    id: 'acciones-agua',
    title: 'Acciones de agua',
    icon: UserGroupIcon,
    items: [
      {
        label: 'Acciones',
        to: '/admin/acciones',
        icon: ClipboardDocumentListIcon,
        permission: ['acciones.accion.ver', 'accion.ver', 'acciones.ver'],
      },

      {
        label: 'Detalle de acción',
        to: '/admin/detalle-pago-accion',
        icon: DocumentChartBarIcon,
        permission: [
          'acciones.detalle.ver',
          'acciones.detalles.ver',
          'detalle_accion.ver',
          'detalle_pago_accion.ver',
        ],
      },
      //Añadido por Becas
      {
        label: 'Tipo Accion',
        to: '/admin/tipo-accion',
        icon: ClipboardDocumentListIcon,
        permission: ['acciones.accion.ver', 'accion.ver', 'acciones.ver'],
      },
      {
        label: 'Cambio de nombre',
        to: '/admin/cambio-nombre',
        icon: ClipboardDocumentCheckIcon,
        permission: ['acciones.accion.ver', 'accion.ver', 'acciones.ver'],
      },
      // {
      //   label: 'Adelanto de pagos',
      //   to: '/admin/acciones/adelantos',
      //   icon: BanknotesIcon,
      //   permission: ['acciones.accion.ver', 'accion.ver', 'acciones.ver'],
      // },
      {
        label: 'Cobros Generales',
        to: '/admin/cobros',
        icon: CreditCardIcon,
        permission: ['cobro.ver', 'cobros.ver', 'pago.ver', 'pagos.ver'],
      },
    ],
  },
  {
    id: 'acciones-alcantarillado',
    title: 'Acciones de alcantarillado',
    icon: UserGroupIcon,
    items: [
      {
        label: 'Acciones Alcantarillado',
        to: '/admin/alcantarillado/acciones',
        icon: WrenchScrewdriverIcon,
        permission: ['acciones.accion.ver', 'accion.ver', 'acciones.ver'],
      },
      {
        label: 'Alcantarillado',
        to: '/admin/alcantarillado',
        icon: WrenchScrewdriverIcon,
        permission: ['acciones.accion.ver', 'accion.ver', 'acciones.ver'],
      },
      {
        label: 'Cobros',
        to: '/admin/alcantarillado-cobros',
        icon: WrenchScrewdriverIcon,
        permission: ['acciones.accion.ver', 'accion.ver', 'acciones.ver'],
      },
    ],
  },
  {
    id: 'cobros',
    title: 'Cobros y pagos',
    icon: BanknotesIcon,
    items: [
      {
        label: 'Cobros Generales',
        to: '/admin/cobros',
        icon: CreditCardIcon,
        permission: ['cobro.ver', 'cobros.ver', 'pago.ver', 'pagos.ver'],
      },
      {
        label: 'Cobros universales',
        to: '/admin/cobros-universales',
        icon: BanknotesIcon,
        permission: ['cobro.ver', 'cobros.ver', 'pago.ver', 'pagos.ver'],
      },
      {
        label: 'Cobros de agua',
        to: '/admin/cobros-agua',
        icon: ReceiptPercentIcon,
        permission: [
          'pago_agua.ver',
          'pago-agua.ver',
          'cobro_agua.ver',
          'cobros_agua.ver',
          'agua.cobro.ver',
        ],
      },

      {
        label: 'Lecturas',
        to: '/admin/lecturas',
        icon: DocumentTextIcon,
        permission: ['lectura.ver', 'lecturas.ver', 'agua.lectura.ver'],
      },
      {
        label: 'Mora',
        to: '/admin/lectura-mora',
        icon: DocumentTextIcon,
        permission: ['lectura.ver', 'lecturas.ver', 'agua.lectura.ver'],
      },
    ],
  },
  {
    id: 'operaciones',
    title: 'Administración',
    icon: WrenchScrewdriverIcon,
    items: [
      {
        label: 'Gestiones',
        to: '/admin/gestiones',
        icon: CalendarDaysIcon,
        permission: ['gestion.ver', 'gestiones.ver'],
      },
      {
        label: 'Periodos',
        to: '/admin/periodos',
        icon: ClipboardDocumentCheckIcon,
        permission: ['periodo.ver', 'periodos.ver', 'gestion.ver'],
      },

      {
        label: 'Calles',
        to: '/admin/calles',
        icon: MapPinIcon,
        permission: ['calle.ver', 'calles.ver', 'acciones.calles.ver'],
      },
      {
        label: 'Tarifas',
        to: '/admin/tarifas',
        icon: AdjustmentsHorizontalIcon,
        permission: ['tarifa.ver', 'tarifas.ver'],
      },
    ],
  },

  {
    id: 'seguridad',
    title: 'Usuarios y Roles',
    icon: ShieldCheckIcon,
    items: [
      {
        label: 'Gestión de usuarios',
        to: '/admin/usuarios',
        icon: UsersIcon,
        permission: ['usuario.ver', 'usuarios.ver', 'auth.usuario.ver'],
      },
      {
        label: 'Roles y permisos',
        to: '/admin/roles',
        icon: ShieldCheckIcon,
        permission: ['rol.ver', 'roles.ver', 'auth.rol.ver'],
      },
    ],
  },

  {
    id: 'configuracion',
    title: 'Configuración',
    icon: Cog6ToothIcon,
    items: [],
  },

  {
    id: 'asambleas',
    title: 'Reportes y Multas',
    icon: UserGroupIcon,
    items: [
      {
        label: 'Multas',
        to: '/admin/asambleas',
        icon: CalendarDaysIcon,
        permission: [
          'asamblea.ver',
          'asambleas.ver',
          'reunion.ver',
          'reuniones.ver',
        ],
      },
      {
        label: 'Otras multas',
        to: '/admin/multas',
        icon: DocumentTextIcon,
        permission: ['multa.ver', 'multas.ver', 'agua.multa.ver'],
      },
      {
        label: 'Reportes generales',
        to: '/admin/reportes',
        icon: ChartBarSquareIcon,
        permission: ['reporte.ver', 'reportes.ver'],
      },
    ],
  },

  {
    id: 'funciones_extras',
    title: 'Funciones',
    icon: Cog6ToothIcon,
    items: [
      {
        label: 'Inventario',
        to: '/admin/inventario',
        icon: ChartBarSquareIcon,
        permission: ['inventario.ver'],
      },
    ],
  },
];
