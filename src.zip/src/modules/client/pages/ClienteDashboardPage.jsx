import {
  HomeIcon,
  UserCircleIcon,
  ClipboardDocumentListIcon,
  CurrencyDollarIcon,
} from '@heroicons/react/24/outline';

import { AuthService } from '../../auth/services/auth.services';

export default function ClienteDashboardPage() {
  const user = AuthService.getUser();

  return (
    <section className="space-y-6">
      <div className="rounded-3xl bg-white p-6 shadow-sm">
        <div className="flex items-center gap-4">
          <div className="rounded-2xl bg-red-50 p-3 text-red-800">
            <HomeIcon className="h-7 w-7" />
          </div>

          <div>
            <h1 className="text-2xl font-bold text-slate-800">
              Bienvenido, {user?.nombre_usuario || 'Usuario'}
            </h1>
            <p className="mt-1 text-sm text-slate-500">
              Panel de usuario de la OTB Huayllani Oeste.
            </p>
          </div>
        </div>
      </div>

      <div className="grid gap-5 md:grid-cols-3">
        <div className="rounded-3xl bg-white p-5 shadow-sm">
          <UserCircleIcon className="mb-4 h-8 w-8 text-red-800" />
          <h3 className="font-bold text-slate-800">Mi información</h3>
          <p className="mt-2 text-sm text-slate-500">
            Consulta tus datos personales registrados.
          </p>
        </div>

        <div className="rounded-3xl bg-white p-5 shadow-sm">
          <CurrencyDollarIcon className="mb-4 h-8 w-8 text-red-800" />
          <h3 className="font-bold text-slate-800">Mis pagos</h3>
          <p className="mt-2 text-sm text-slate-500">
            Revisa pagos, cuotas o conceptos pendientes.
          </p>
        </div>

        <div className="rounded-3xl bg-white p-5 shadow-sm">
          <ClipboardDocumentListIcon className="mb-4 h-8 w-8 text-red-800" />
          <h3 className="font-bold text-slate-800">Comunicados</h3>
          <p className="mt-2 text-sm text-slate-500">
            Próximamente podrás ver avisos de la OTB.
          </p>
        </div>
      </div>
    </section>
  );
}