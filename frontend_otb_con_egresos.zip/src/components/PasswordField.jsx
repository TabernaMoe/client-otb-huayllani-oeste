import { useState } from 'react';
import { EyeIcon, EyeSlashIcon } from '@heroicons/react/24/outline';
 
export default function PasswordField({
  label,
  error,
  value,
  errorMode = 'message', // 'border' | 'message'
  className = '',
  ...props
}) {
  const [show, setShow] = useState(false);

  const base =
    'w-full rounded-xl border px-3 py-2 text-sm shadow-sm pr-10 ' +
    'focus:outline-none focus:ring-2 min-w-[130px]';

  const normal =
    'border-slate-300 text-slate-700 focus:border-emerald-600 focus:ring-emerald-600';

  const danger =
    'border-sky-500 text-sky-700 focus:border-sky-500 focus:ring-sky-500';

  const showError = Boolean(error);
  const showMessage = showError && errorMode === 'message';

  return (
    <div className={className}>
      {label && (
        <label className="mb-1 block text-sm font-medium text-slate-700">
          {label}
        </label>
      )}

      <div className="relative">
        <input
          {...props}
          type={show ? 'text' : 'password'}
          value={value ?? ''}
          aria-invalid={showError}
          className={`${base} ${showError ? danger : normal}`}
        />

        {/* Botón mostrar / ocultar */}
        <button
          type="button"
          onClick={() => setShow((s) => !s)}
          className="absolute inset-y-0 right-0 flex items-center px-3 text-slate-500 hover:text-slate-700"
          aria-label={show ? 'Ocultar contraseña' : 'Mostrar contraseña'}
        >
          {show ? (
            <EyeSlashIcon className="h-5 w-5" />
          ) : (
            <EyeIcon className="h-5 w-5" />
          )}
        </button>
      </div>

      {showMessage && <p className="mt-1 text-xs text-red-600">{error}</p>}
    </div>
  );
}
